#!/bin/bash
rm domains.txt
if [ -e serverinstaled.txt ]
then
    echo "server installed, making domains"
else
    echo "server not installed, installing..."
    read -p "Enter server IP: " serverip
serverip=${serverip}

# Update and install Apache and required packages
apt update && apt install -y \
    curl php-curl vim unzip fail2ban php apache2 libapache2-mod-php php-apcu php-bcmath php-mbstring php-soap php-mysql \
    php-curl mcrypt php-zip certbot curl php-gd php-parser php-imagick php-phpseclib php-common php-mysql php-gd \
    php-imap php-json php-curl php-zip php-xml php-mbstring php-bz2 php-intl php-gmp php-sqlite3 vim

# Create and configure remoteip.conf for Apache
cat <<EOT > /etc/apache2/conf-available/remoteip.conf
RemoteIPHeader X-Forwarded-For
RemoteIPTrustedProxy 127.0.0.1
EOT

# Enable necessary Apache modules and configuration
a2enmod remoteip rewrite
a2enconf remoteip

# Modify apache2.conf to update directory settings
sed -i 's/Options Indexes FollowSymLinks/Options FollowSymLinks/' /etc/apache2/apache2.conf
sed -i 's/AllowOverride None/AllowOverride All/' /etc/apache2/apache2.conf

# Update Apache's default site configuration
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /var/www/site|' /etc/apache2/sites-enabled/000-default.conf

# Create the directory for the primary domain
mkdir -p /var/www/site

# Update Apache to listen on localhost
sed -i 's|Listen 80|Listen 127.0.0.1:80|' /etc/apache2/ports.conf

# Stop Apache to avoid conflicts with Nginx
service apache2 stop

# Install Nginx and additional packages
apt install -y nginx php-fpm curl python3-certbot-nginx certbot fail2ban torsocks php-mysql unzip vim php-zip \
    php-apcu php-bcmath php-mbstring php-soap php-mysql php-curl mcrypt php-zip certbot curl php-gd

# Update Nginx default site configuration
read -r -d '' DefaultNGINX << EOM
server {
        listen 80 default_server;
        root /var/www/html;
        index index.html;
        server_name _;
location ^~ /.well-known/acme-challenge/ {
   default_type "text/plain";
    root         /var/www/letsencrypt;
}
EOM

echo "$DefaultNGINX" > /etc/nginx/sites-available/default

sed -i "s|listen 80 default_server;|listen "$serverip":80 default_server;|" /etc/nginx/sites-enabled/default

# Restart Nginx and Apache services
service nginx restart
service apache2 restart


 touch serverinstaled.txt
fi
# Ask for the number of websites
echo "Are you setting up one website or multiple websites? (Enter '1' for one or '2' for multiple)"
read choice

if [ "$choice" -eq 1 ]; then
    echo "Enter the domain name for your website:"
    read domain
        read -p "Enter server IP: " serverip
serverip=${serverip}

    domains=("$domain")
elif [ "$choice" -eq 2 ]; then
	    read -p "Enter server IP: " serverip
serverip=${serverip}

    echo "Enter the number of websites you want to set up:"
    read num_sites
    domains=()
    for (( i=1; i<=num_sites; i++ ))
    do
        echo "Enter the domain name for website $i:"
        read domain
        domains+=("$domain")
    done
else
    echo "Invalid choice. Please run the script again and choose either '1' or '2'."
    exit 1
fi
for i in "${!domains[@]}"; do
    domain=${domains[$i]}
echo $domain >> domains.txt
done

input="domains.txt"
while read domainname
do
cp nginx.conf $domainname
cp apache.conf $domainname-apache.conf
sed -i "s/DEFAULTDOMNAME/$domainname/g" $domainname
sed -i "s/DEFAULTIP/$serverip/g" $domainname
sed -i "s/DEFAULTDOMNAME/$domainname/g" $domainname-apache.conf
mkdir /var/www/$domainname
cp $domainname /etc/nginx/sites-enabled/
cp $domainname-apache.conf /etc/apache2/sites-enabled/
mkdir -p /var/www/letsencrypt &&  certbot certonly --email info@domain.com --rsa-key-size 4096 --agree-tos --webroot -w=/var/www/letsencrypt -d $domainname


done < "$input"


service apache2 restart
service nginx restart

echo "Setup complete for ${#domains[@]} website(s)!"
